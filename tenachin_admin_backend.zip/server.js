const express = require('express');
const cors = require('cors');
const helmet = require('helmet'); // New: Security headers
const rateLimit = require('express-rate-limit'); // New: Rate limiting
require('dotenv').config();

const dataRoutes = require('./src/routes/dataRoutes');

const app = express();

// --- 1. SECURITY MIDDLEWARE ---
app.use(helmet()); // Sets security headers (XSS protection, Hide Express, etc.)
app.use(cors());
app.use(express.json({ limit: '10kb' })); // Security: Limit body size to prevent memory attacks

// --- 2. GLOBAL RATE LIMITING ---
const generalLimit = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per window
  message: { error: "Too many requests, please try again later." },
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api', generalLimit);

// --- 3. STRICT AUTH RATE LIMITING (Brute-force protection) ---
const authLimit = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10, // Only 10 login attempts per hour per IP
  message: { error: "Too many login attempts. Access locked for 1 hour." },
});
// Apply this specifically to your login path
app.use('/api/auth', authLimit);

// --- 4. ROUTES ---

// Root Health Check
app.get('/', (req, res) => {
  res.json({
    status: "Success",
    message: "Tenachin API is live",
    timestamp: new Date().toISOString()
  });
});

// Specific API Status
app.get('/api/status', (req, res) => {
  res.json({ service: "Tenachin Backend", online: true });
});

// Existing API Routes
app.use('/api', dataRoutes);

// --- 5. ERROR HANDLING (Security Best Practice) ---
// Don't leak stack traces to the user
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: "Internal Server Error" });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`✅ Tenachin Backend Secured & Running on port ${PORT}`);
});